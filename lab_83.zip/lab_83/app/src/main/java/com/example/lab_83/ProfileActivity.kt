package com.example.lab_83
import android.Manifest
import android.annotation.SuppressLint
import android.app.NotificationChannel
import android.app.NotificationManager
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.media.MediaPlayer
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.provider.Settings
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import android.widget.VideoView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat

class ProfileActivity : AppCompatActivity() {
    private val CHANNEL_ID = "simple"
    private val NOTIFICATION_ID = 2324
    private val CAMERA_PERMISSION_CODE = 101
    private val CAMERA_REQUEST_CODE = 102
    private val BLUETOOTH_PERMISSION_CODE = 103
    private val BLUETOOTH_ENABLE_REQUEST_CODE = 104

    private lateinit var bluetoothButton: Button
    private lateinit var wifiButton: Button
    private lateinit var mediaPlayer: MediaPlayer
    private lateinit var videoView: VideoView
    private lateinit var imageView: ImageView
    private lateinit var captureButton: Button
    private lateinit var bluetoothAdapter: BluetoothAdapter
    private lateinit var wifiManager: WifiManager

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile)

        val sharedPref = getSharedPreferences("userPrefs", Context.MODE_PRIVATE)
        val name = sharedPref.getString("username", "GUEST")
        val phn = sharedPref.getString("phn", "NOT FOUND")

        val n = findViewById<TextView>(R.id.name)
        val p = findViewById<TextView>(R.id.phn)
        n.text = "name: $name"
        p.text = "phone number: $phn"

        val nbtn = findViewById<Button>(R.id.notifybtn)
        createNotification()
        nbtn.setOnClickListener{
            sendNotification()
        }

        setupAudio()
        setupVideo()
        setupBluetooth()
        setupWifi()

        imageView = findViewById(R.id.imageView)
        captureButton = findViewById(R.id.captureButton)

        captureButton.setOnClickListener {
            if (checkCameraPermission()) {
                openCamera()
            } else {
                requestCameraPermission()
            }
        }
    }

    private fun createNotification(){
        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.O){
            val channel = NotificationChannel(
                CHANNEL_ID,
                "simple_channel",
                NotificationManager.IMPORTANCE_DEFAULT
            )
            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.createNotificationChannel(channel)
        }
    }

    private fun sendNotification(){
        val notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentTitle("Sample Notification")
            .setContentText("This is a sample Notification")
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .build()
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.notify(NOTIFICATION_ID, notification)
    }

    private fun setupAudio() {
        mediaPlayer = MediaPlayer.create(this, R.raw.audio_file)
        val playButton = findViewById<Button>(R.id.play_audio_button)
        playButton.setOnClickListener {
            if (mediaPlayer.isPlaying) {
                mediaPlayer.pause()
                playButton.text = "Play Audio"
            } else {
                mediaPlayer.start()
                playButton.text = "Pause Audio"
            }
        }
        val stopButton = findViewById<Button>(R.id.stop_audio_button)
        stopButton.setOnClickListener {
            mediaPlayer.stop()
            mediaPlayer = MediaPlayer.create(this, R.raw.audio_file)
            playButton.text = "Play Audio"
        }
    }

    private fun setupVideo() {
        videoView = findViewById(R.id.video_view)
        val videoPath = "android.resource://$packageName/${R.raw.video_file}"
        videoView.setVideoURI(Uri.parse(videoPath))
        val playButton = findViewById<Button>(R.id.play_video_button)
        playButton.setOnClickListener {
            if (videoView.isPlaying) {
                videoView.pause()
                playButton.text = "Play Video"
            } else {
                videoView.start()
                playButton.text = "Pause Video"
            }
        }
        val stopButton = findViewById<Button>(R.id.stop_video_button)
        stopButton.setOnClickListener {
            videoView.stopPlayback()
            videoView.setVideoURI(Uri.parse(videoPath))
            playButton.text = "Play Video"
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        if (::mediaPlayer.isInitialized) {
            mediaPlayer.release()
        }
    }

    private fun checkCameraPermission(): Boolean {
        return ContextCompat.checkSelfPermission(
            this,
            Manifest.permission.CAMERA
        ) == PackageManager.PERMISSION_GRANTED
    }

    private fun requestCameraPermission() {
        ActivityCompat.requestPermissions(
            this,
            arrayOf(Manifest.permission.CAMERA),
            CAMERA_PERMISSION_CODE
        )
    }

    private fun openCamera() {
        val cameraIntent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        startActivityForResult(cameraIntent, CAMERA_REQUEST_CODE)
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == CAMERA_PERMISSION_CODE) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                openCamera()
            } else {
                Toast.makeText(this, "Camera permission denied", Toast.LENGTH_SHORT).show()
            }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == CAMERA_REQUEST_CODE && resultCode == RESULT_OK) {
            val imageBitmap = data?.extras?.get("data") as Bitmap
            imageView.setImageBitmap(imageBitmap)
        } else if (requestCode == BLUETOOTH_ENABLE_REQUEST_CODE && resultCode == RESULT_OK) {
            bluetoothButton.text = "Turn OFF Bluetooth"
            Toast.makeText(this, "Bluetooth turned on", Toast.LENGTH_SHORT).show()
        }
    }

    private fun setupBluetooth() {
        val bluetoothManager = getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
        bluetoothAdapter = bluetoothManager.adapter
        bluetoothButton = findViewById(R.id.bluetoothButton)

        try {
            bluetoothButton.text = if (bluetoothAdapter.isEnabled) "Turn OFF Bluetooth" else "Turn ON Bluetooth"
        } catch (e: SecurityException) {
            bluetoothButton.text = "Bluetooth (Permission Required)"
        }

        bluetoothButton.setOnClickListener {
            if (bluetoothAdapter == null) {
                Toast.makeText(this, "Device doesn't support Bluetooth", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                if (ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT) ==
                    PackageManager.PERMISSION_GRANTED) {
                    val intent = Intent(Settings.ACTION_BLUETOOTH_SETTINGS)
                    startActivity(intent)
                    Toast.makeText(this, "Please toggle Bluetooth in settings", Toast.LENGTH_SHORT).show()
                } else {
                    ActivityCompat.requestPermissions(
                        this,
                        arrayOf(Manifest.permission.BLUETOOTH_CONNECT),
                        BLUETOOTH_PERMISSION_CODE
                    )
                }
            } else {
                try {
                    if (bluetoothAdapter.isEnabled) {
                        bluetoothAdapter.disable()
                        Toast.makeText(this, "Bluetooth turned off", Toast.LENGTH_SHORT).show()
                        bluetoothButton.text = "Turn ON Bluetooth"
                    } else {
                        val enableBtIntent = Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE)
                        startActivityForResult(enableBtIntent, BLUETOOTH_ENABLE_REQUEST_CODE)
                    }
                } catch (e: SecurityException) {
                    Toast.makeText(this, "Bluetooth permission required", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    private fun setupWifi() {
        wifiManager = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        wifiButton = findViewById(R.id.wifiButton)

        wifiButton.text = if (wifiManager.isWifiEnabled) "Turn OFF WiFi" else "Turn ON WiFi"

        wifiButton.setOnClickListener {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val intent = Intent(Settings.ACTION_WIFI_SETTINGS)
                startActivity(intent)
                Toast.makeText(this, "Please toggle WiFi in settings", Toast.LENGTH_SHORT).show()
            } else {
                try {
                    wifiManager.isWifiEnabled = !wifiManager.isWifiEnabled
                    Toast.makeText(
                        this,
                        if (wifiManager.isWifiEnabled) "WiFi turned on" else "WiFi turned off",
                        Toast.LENGTH_SHORT
                    ).show()
                } catch (e: SecurityException) {
                    Toast.makeText(this, "Cannot toggle WiFi", Toast.LENGTH_SHORT).show()
                }
            }

            wifiButton.text = if (wifiManager.isWifiEnabled) "Turn OFF WiFi" else "Turn ON WiFi"
        }
    }
}