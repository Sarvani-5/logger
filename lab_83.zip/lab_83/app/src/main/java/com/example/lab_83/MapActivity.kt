package com.example.lab_83

import android.Manifest
import android.content.pm.PackageManager
import android.location.Geocoder
import android.location.Location
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import org.osmdroid.config.Configuration
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.Marker
import java.io.IOException
import java.util.Locale
import android.preference.PreferenceManager

// This class will hold location information with distance
data class LocationInfo(
    val address: String,
    val description: String,
    val latitude: Double,
    val longitude: Double,
    var distanceToUser: Float = Float.MAX_VALUE
)

class MapActivity : AppCompatActivity() {

    private lateinit var map: MapView
    private lateinit var geocoder: Geocoder
    private lateinit var btnNearby: Button
    private lateinit var fusedLocationClient: FusedLocationProviderClient
    private val LOCATION_PERMISSION_REQUEST_CODE = 1001

    // List to store all added locations
    private val allLocations = mutableListOf<LocationInfo>()

    // Maximum range to consider a location "nearby" (in meters)
    private val NEARBY_RADIUS = 5000f  // 5km radius

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val ctx = applicationContext
        Configuration.getInstance().load(ctx, PreferenceManager.getDefaultSharedPreferences(ctx))
        setContentView(R.layout.activity_map)

        map = findViewById(R.id.map)
        btnNearby = findViewById(R.id.btn_nearby)

        map.setTileSource(TileSourceFactory.MAPNIK)
        map.setMultiTouchControls(true)
        map.controller.setZoom(14.0)

        geocoder = Geocoder(this, Locale.getDefault())
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)

        // Add initial markers - these will also be stored in our allLocations list
        addMarkerByLocationName("No:336,Thuttukadai vanniya konar lane,North Masi Stree,Madurai-625001", "Sakthi's House")
        addMarkerByLocationName("Thiagarajar College Of Engineering,Thiruparankundram,Madurai-625001", "Sakthi's College")

        // You can add more locations here
        addMarkerByLocationName("Meenakshi Amman Temple, Madurai-625001", "Meenakshi Temple")
        addMarkerByLocationName("Mattuthavani Bus Stand, Madurai-625007", "Main Bus Station")
        addMarkerByLocationName("Madurai Junction Railway Station, Madurai-625001", "Railway Station")

        // Set up nearby button click listener
        btnNearby.setOnClickListener {
            checkLocationPermissionAndShowNearbyLocations()
        }
    }

    private fun checkLocationPermissionAndShowNearbyLocations() {
        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_FINE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.ACCESS_FINE_LOCATION),
                LOCATION_PERMISSION_REQUEST_CODE
            )
        } else {
            showNearbyLocations()
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        when (requestCode) {
            LOCATION_PERMISSION_REQUEST_CODE -> {
                if ((grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED)) {
                    showNearbyLocations()
                } else {
                    Toast.makeText(this, "Location permission denied, cannot show nearby locations", Toast.LENGTH_SHORT).show()
                }
                return
            }
        }
    }

    private fun showNearbyLocations() {
        if (ActivityCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_FINE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            return
        }

        fusedLocationClient.lastLocation.addOnSuccessListener { userLocation ->
            if (userLocation != null) {
                // Clear existing markers
                map.overlays.clear()

                // Add user's current location marker
                val currentLocation = GeoPoint(userLocation.latitude, userLocation.longitude)
                map.controller.setCenter(currentLocation)

                val userMarker = Marker(map)
                userMarker.position = currentLocation
                userMarker.title = "Your Location"
                userMarker.snippet = "You are here"
                userMarker.setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM)
                map.overlays.add(userMarker)

                // Show loading message
                Toast.makeText(this, "Finding nearby locations...", Toast.LENGTH_SHORT).show()

                // Calculate distances for all locations
                for (location in allLocations) {
                    val locationPoint = Location("point")
                    locationPoint.latitude = location.latitude
                    locationPoint.longitude = location.longitude

                    location.distanceToUser = userLocation.distanceTo(locationPoint)
                }

                // Sort locations by distance to user
                val sortedLocations = allLocations.sortedBy { it.distanceToUser }

                // Add markers for nearby locations (within NEARBY_RADIUS)
                val nearbyLocations = sortedLocations.filter { it.distanceToUser <= NEARBY_RADIUS }

                if (nearbyLocations.isEmpty()) {
                    Toast.makeText(this, "No locations found within ${NEARBY_RADIUS/1000}km", Toast.LENGTH_LONG).show()

                    // If no nearby locations, show the closest 3 regardless of distance
                    val closestLocations = sortedLocations.take(3)
                    for (location in closestLocations) {
                        addMarkerForLocation(location, true)
                    }
                } else {
                    // Add markers for nearby locations
                    for (location in nearbyLocations) {
                        addMarkerForLocation(location, true)
                    }

                    Toast.makeText(this, "Found ${nearbyLocations.size} locations nearby", Toast.LENGTH_SHORT).show()
                }

                map.invalidate()
            } else {
                Toast.makeText(this, "Could not get current location", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun addMarkerForLocation(location: LocationInfo, showDistance: Boolean = false) {
        val geoPoint = GeoPoint(location.latitude, location.longitude)
        val marker = Marker(map)
        marker.position = geoPoint
        marker.setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM)
        marker.title = location.description

        if (showDistance) {
            val distanceKm = location.distanceToUser / 1000f
            marker.snippet = "${location.address}\nDistance: ${String.format("%.2f", distanceKm)} km"
        } else {
            marker.snippet = location.address
        }

        map.overlays.add(marker)
    }

    private fun addMarkerByLocationName(locationName: String, description: String) {
        try {
            val addresses = geocoder.getFromLocationName(locationName, 1)
            if (addresses != null && addresses.size > 0) {
                val address = addresses[0]
                val geoPoint = GeoPoint(address.latitude, address.longitude)

                // Store the location info
                val locationInfo = LocationInfo(
                    address = locationName,
                    description = description,
                    latitude = address.latitude,
                    longitude = address.longitude
                )
                allLocations.add(locationInfo)

                // Add marker to map
                val marker = Marker(map)
                marker.position = geoPoint
                marker.setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM)
                marker.title = description
                marker.snippet = locationName
                map.overlays.add(marker)

                // Center map on the last added location
                map.controller.setCenter(geoPoint)

            } else {
                Toast.makeText(this, "Could not find: $locationName", Toast.LENGTH_SHORT).show()
            }
        } catch (e: IOException) {
            Toast.makeText(this, "Error finding location: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onResume() {
        super.onResume()
        map.onResume()
    }

    override fun onPause() {
        super.onPause()
        map.onPause()
    }
}