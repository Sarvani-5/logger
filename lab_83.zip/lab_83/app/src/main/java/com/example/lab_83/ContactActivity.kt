package com.example.lab_83
import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.tlab.R
import com.google.firebase.firestore.FirebaseFirestore
class ContactActivity : AppCompatActivity() {
    private lateinit var db: FirebaseFirestore
    private lateinit var idEditText: EditText
    private lateinit var nameEditText: EditText
    private lateinit var phoneEditText: EditText
    private lateinit var saveButton: Button
    private lateinit var loadButton: Button
    private lateinit var contactsTextView: TextView
    private lateinit var deleteIdEditText: EditText
    private lateinit var deleteButton: Button
    private lateinit var updateIdEditText: EditText
    private lateinit var updateNameEditText: EditText
    private lateinit var updatePhoneEditText: EditText
    private lateinit var findButton: Button
    private lateinit var updateButton: Button
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_contact)
        db = FirebaseFirestore.getInstance()
        idEditText = findViewById(R.id.editTextId)
        nameEditText = findViewById(R.id.editTextName)
        phoneEditText = findViewById(R.id.editTextPhone)
        saveButton = findViewById(R.id.buttonSave)
        loadButton = findViewById(R.id.buttonLoad)
        contactsTextView = findViewById(R.id.textViewContacts)
        deleteIdEditText = findViewById(R.id.editTextDeleteId)
        deleteButton = findViewById(R.id.buttonDelete)
        updateIdEditText = findViewById(R.id.editTextUpdateId)
        updateNameEditText = findViewById(R.id.editTextUpdateName)
        updatePhoneEditText = findViewById(R.id.editTextUpdatePhone)
        findButton = findViewById(R.id.buttonFind)
        updateButton = findViewById(R.id.buttonUpdate)
        saveButton.setOnClickListener {
            saveContact()
        }
        loadButton.setOnClickListener {
            loadContacts()
        }
        deleteButton.setOnClickListener {
            deleteContact()
        }
        findButton.setOnClickListener {
            findContactById()
        }
        updateButton.setOnClickListener {
            updateContact()
        }
        loadContacts()
    }
    private fun saveContact() {
        val id = idEditText.text.toString().trim()
        val name = nameEditText.text.toString().trim()
        val phoneNumber = phoneEditText.text.toString().trim()
        if (id.isEmpty() || name.isEmpty() || phoneNumber.isEmpty()) {
            Toast.makeText(this, "Please enter ID, name and phone number", Toast.LENGTH_SHORT).show()
            return
        }
        val contact = hashMapOf(
            "id" to id,
            "name" to name,
            "phoneNumber" to phoneNumber
        )
        db.collection("contacts")
            .document(id)
            .set(contact)
            .addOnSuccessListener {
                Toast.makeText(this, "Contact saved successfully with ID: $id", Toast.LENGTH_SHORT).show()
                idEditText.text.clear()
                nameEditText.text.clear()
                phoneEditText.text.clear()
                loadContacts()
            }
            .addOnFailureListener { e ->
                Toast.makeText(this, "Error saving contact: ${e.message}", Toast.LENGTH_SHORT).show()
            }
    }
    private fun loadContacts() {
        contactsTextView.text = "Loading contacts..."
        db.collection("contacts")
            .get()
            .addOnSuccessListener { result ->
                val stringBuilder = StringBuilder()
                if (result.isEmpty) {
                    stringBuilder.append("No contacts found.")
                } else {
                    for (document in result) {
                        val id = document.getString("id") ?: document.id
                        val name = document.getString("name") ?: "Unknown"
                        val phone = document.getString("phoneNumber") ?: "No number"
                        stringBuilder.append("ID: $id\nName: $name\nPhone: $phone\n\n")
                    }
                }
                contactsTextView.text = stringBuilder.toString()
            }
            .addOnFailureListener { e ->
                contactsTextView.text = "Error loading contacts: ${e.message}"
            }
    }

    private fun deleteContact() {
        val idToDelete = deleteIdEditText.text.toString().trim()
        if (idToDelete.isEmpty()) {
            Toast.makeText(this, "Please enter an ID to delete", Toast.LENGTH_SHORT).show()
            return
        }
        db.collection("contacts")
            .document(idToDelete)
            .delete()
            .addOnSuccessListener {
                Toast.makeText(this, "Contact with ID: $idToDelete deleted successfully", Toast.LENGTH_SHORT).show()
                deleteIdEditText.text.clear()
                loadContacts()
            }
            .addOnFailureListener { e ->
                Toast.makeText(this, "Error deleting contact: ${e.message}", Toast.LENGTH_SHORT).show()
            }
    }

    private fun findContactById() {
        val idToFind = updateIdEditText.text.toString().trim()
        if (idToFind.isEmpty()) {
            Toast.makeText(this, "Please enter an ID to find", Toast.LENGTH_SHORT).show()
            return
        }
        db.collection("contacts")
            .document(idToFind)
            .get()
            .addOnSuccessListener { document ->
                if (document != null && document.exists()) {
                    val name = document.getString("name") ?: ""
                    val phone = document.getString("phoneNumber") ?: ""
                    updateNameEditText.setText(name)
                    updatePhoneEditText.setText(phone)
                    Toast.makeText(this, "Contact found", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(this, "No contact found with ID: $idToFind", Toast.LENGTH_SHORT).show()
                    updateNameEditText.text.clear()
                    updatePhoneEditText.text.clear()
                }
            }
            .addOnFailureListener { e ->
                Toast.makeText(this, "Error finding contact: ${e.message}", Toast.LENGTH_SHORT).show()
            }
    }
    private fun updateContact() {
        val idToUpdate = updateIdEditText.text.toString().trim()
        val updatedName = updateNameEditText.text.toString().trim()
        val updatedPhone = updatePhoneEditText.text.toString().trim()
        if (idToUpdate.isEmpty() || updatedName.isEmpty() || updatedPhone.isEmpty()) {
            Toast.makeText(this, "Please enter ID, updated name and phone number", Toast.LENGTH_SHORT).show()
            return
        }
        val updatedContact = hashMapOf(
            "id" to idToUpdate,
            "name" to updatedName,
            "phoneNumber" to updatedPhone
        )
        db.collection("contacts")
            .document(idToUpdate)
            .set(updatedContact)
            .addOnSuccessListener {
                Toast.makeText(this, "Contact updated successfully", Toast.LENGTH_SHORT).show()
                updateIdEditText.text.clear()
                updateNameEditText.text.clear()
                updatePhoneEditText.text.clear()
                loadContacts()
            }
            .addOnFailureListener { e ->
                Toast.makeText(this, "Error updating contact: ${e.message}", Toast.LENGTH_SHORT).show()
            }
    }
}class EventActivity : AppCompatActivity() {

    private lateinit var nameEditText: EditText
    private lateinit var locationEditText: EditText
    private lateinit var addButton: Button
    private lateinit var eventsListView: ListView
    private lateinit var adapter: ArrayAdapter<String>
    private lateinit var dbHelper: EventDatabaseHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_events)
        dbHelper = EventDatabaseHelper(this)

        nameEditText = findViewById(R.id.editTextName)
        locationEditText = findViewById(R.id.editTextLocation)
        addButton = findViewById(R.id.buttonAdd)
        eventsListView = findViewById(R.id.listViewEvents)
        adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, ArrayList<String>())
        eventsListView.adapter = adapter
        loadEvents()

        addButton.setOnClickListener {
            addEvent()
        }

        eventsListView.setOnItemLongClickListener { _, _, position, _ ->
            val eventString = adapter.getItem(position) ?: return@setOnItemLongClickListener false
            val id = eventString.split(" - ")[0].toInt()
            deleteEvent(id)
            true
        }
    }

    private fun addEvent() {
        val name = nameEditText.text.toString().trim()
        val location = locationEditText.text.toString().trim()

        if (name.isEmpty() || location.isEmpty()) {
            Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show()
            return
        }

        val id = dbHelper.addEvent(name, location)

        if (id != -1L) {
            nameEditText.text.clear()
            locationEditText.text.clear()

            loadEvents()

            Toast.makeText(this, "Event added successfully", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(this, "Failed to add event", Toast.LENGTH_SHORT).show()
        }
    }

    private fun deleteEvent(id: Int) {
        val deleted = dbHelper.deleteEvent(id)

        if (deleted > 0) {
            loadEvents()
            Toast.makeText(this, "Event deleted", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(this, "Failed to delete event", Toast.LENGTH_SHORT).show()
        }
    }

    private fun loadEvents() {
        adapter.clear()

        val eventsList = dbHelper.getAllEvents()

        for (event in eventsList) {
            adapter.add("${event.id} - ${event.name} - ${event.location}")
        }

        adapter.notifyDataSetChanged()
    }
}

data class Event(val id: Int, val name: String, val location: String)

class EventDatabaseHelper(context: Context) :
    SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {

    companion object {
        private const val DATABASE_NAME = "events.db"
        private const val DATABASE_VERSION = 1
        private const val TABLE_EVENTS = "events"
        private const val COLUMN_ID = "id"
        private const val COLUMN_NAME = "name"
        private const val COLUMN_LOCATION = "location"
    }

    override fun onCreate(db: SQLiteDatabase) {
        val createTableSQL = """
            CREATE TABLE $TABLE_EVENTS (
                $COLUMN_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                $COLUMN_NAME TEXT NOT NULL,
                $COLUMN_LOCATION TEXT NOT NULL
            )
        """.trimIndent()

        db.execSQL(createTableSQL)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS $TABLE_EVENTS")
        onCreate(db)
    }

    fun addEvent(name: String, location: String): Long {
        val db = this.writableDatabase
        val values = ContentValues().apply {
            put(COLUMN_NAME, name)
            put(COLUMN_LOCATION, location)
        }

        val id = db.insert(TABLE_EVENTS, null, values)
        db.close()
        return id
    }

    fun deleteEvent(id: Int): Int {
        val db = this.writableDatabase
        val result = db.delete(TABLE_EVENTS, "$COLUMN_ID = ?", arrayOf(id.toString()))
        db.close()
        return result
    }

    fun getAllEvents(): List<Event> {
        val eventsList = ArrayList<Event>()
        val db = this.readableDatabase
        val query = "SELECT * FROM $TABLE_EVENTS"
        val cursor = db.rawQuery(query, null)

        if (cursor.moveToFirst()) {
            do {
                val id = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_ID))
                val name = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_NAME))
                val location = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_LOCATION))

                val event = Event(id, name, location)
                eventsList.add(event)
            } while (cursor.moveToNext())
        }

        cursor.close()
        db.close()
        return eventsList
    }
}