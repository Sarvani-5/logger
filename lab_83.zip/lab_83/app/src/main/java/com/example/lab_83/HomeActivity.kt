package com.example.lab_83

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.Button
import android.widget.EditText
import android.widget.TableLayout
import android.widget.TableRow
import android.widget.TextView
import android.widget.Toast
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity


class HomeActivity : AppCompatActivity() {

    private lateinit var etExpenseAmount: EditText
    private lateinit var etExpenseDescription: EditText
    private lateinit var btnAddWeekly: Button
    private lateinit var btnAddMonthly: Button
    private lateinit var tableLayout: TableLayout

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)

        // Initialize views
        etExpenseAmount = findViewById(R.id.etExpenseAmount)
        etExpenseDescription = findViewById(R.id.etExpenseDescription)
        btnAddWeekly = findViewById(R.id.btnAddWeekly)
        btnAddMonthly = findViewById(R.id.btnAddMonthly)
        tableLayout = findViewById(R.id.tableLayout)

        // Set click listeners for buttons
        btnAddWeekly.setOnClickListener {
            addExpense("Weekly")
        }

        btnAddMonthly.setOnClickListener {
            addExpense("Monthly")
        }
    }

    private fun addExpense(expenseType: String) {
        val amount = etExpenseAmount.text.toString()
        val description = etExpenseDescription.text.toString()

        // Validate inputs
        if (amount.isEmpty() || description.isEmpty()) {
            Toast.makeText(this, "Please enter both amount and description", Toast.LENGTH_SHORT).show()
            return
        }

        try {
            // Create new table row
            val tableRow = TableRow(this)

            // Add description to the row
            val tvDescription = TextView(this)
            tvDescription.text = description
            tvDescription.setPadding(10, 10, 10, 10)
            tableRow.addView(tvDescription)

            // Add amount to the row
            val tvAmount = TextView(this)
            tvAmount.text = "₹$amount"
            tvAmount.setPadding(10, 10, 10, 10)
            tableRow.addView(tvAmount)

            // Add expense type to the row
            val tvType = TextView(this)
            tvType.text = expenseType
            tvType.setPadding(10, 10, 10, 10)
            tableRow.addView(tvType)

            // Add the row to the table
            tableLayout.addView(tableRow)

            // Clear input fields
            etExpenseAmount.text.clear()
            etExpenseDescription.text.clear()

            Toast.makeText(this, "$expenseType expense added", Toast.LENGTH_SHORT).show()

        } catch (e: Exception) {
            Toast.makeText(this, "Error: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.options_menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when(item.itemId){
            R.id.profile -> {
                val intent = Intent(this, ProfileActivity::class.java)
                startActivity(intent)
                true
            }
            R.id.settings -> {
                val intent = Intent(this, SettingsActivity::class.java)
                startActivity(intent)
                true
            }
            R.id.about -> {
                val intent = Intent(this, AboutActivity::class.java)
                startActivity(intent)
                true
            }
            R.id.map -> {
                val intent = Intent(this, MapActivity::class.java)
                startActivity(intent)
                true
            }
            R.id.events -> {
                val intent = Intent(this, EventActivity::class.java)
                startActivity(intent)
                true
            }
            R.id.con -> {
                val intent = Intent(this, ContactActivity::class.java)
                startActivity(intent)
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }
}