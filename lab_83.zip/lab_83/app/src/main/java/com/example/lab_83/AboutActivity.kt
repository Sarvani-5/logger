package com.example.lab_83
import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.view.ContextMenu
import android.view.MenuItem
import android.view.View
import android.widget.Button
import android.widget.PopupMenu
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import android.Manifest
import android.telephony.SmsManager
import android.view.animation.AnimationUtils
import android.widget.TextView

class AboutActivity : AppCompatActivity() {
    private val phoneNumber = "9751423916"
    private val SMS_PERMISSION_REQUEST_CODE = 101

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_about)
        val titleTextView: TextView = findViewById(R.id.tvTitle)
        val descriptionTextView: TextView = findViewById(R.id.tvDescription)
        val contact_btn = findViewById<Button>(R.id.contact)
        val rate_btn = findViewById<Button>(R.id.rate)
        val fadeInAnimation = AnimationUtils.loadAnimation(this, R.anim.fade_in)
        val slideUpAnimation = AnimationUtils.loadAnimation(this, R.anim.slide_up)
        titleTextView.startAnimation(fadeInAnimation)
        descriptionTextView.startAnimation(slideUpAnimation)
        contact_btn.setOnClickListener { view ->
            showPopup(view)
        }

        registerForContextMenu(rate_btn)
    }

    private fun showPopup(view: View) {
        val popup = PopupMenu(this, view)
        popup.menuInflater.inflate(R.menu.popup_menu, popup.menu)

        popup.setOnMenuItemClickListener { item ->
            when(item.itemId) {
                R.id.sms -> {
                    sendSMS()
                    true
                }
                R.id.whatsapp -> {
                    openWhatsApp()
                    true
                }
                R.id.receive_sms -> {
                    receiveSMS()
                    true
                }
                else -> false
            }
        }

        popup.show()
    }

    private fun sendSMS() {
        try {
            val smsIntent = Intent(Intent.ACTION_VIEW)
            smsIntent.data = Uri.parse("sms:$phoneNumber")
            smsIntent.putExtra("sms_body", "Hello from my app!")
            startActivity(smsIntent)
            Toast.makeText(this, "Opening SMS to $phoneNumber", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Unable to open SMS app", Toast.LENGTH_SHORT).show()
        }
    }

    private fun receiveSMS() {
        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.SEND_SMS
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.SEND_SMS),
                SMS_PERMISSION_REQUEST_CODE
            )
        } else {
            try {
                val smsManager = SmsManager.getDefault()
                smsManager.sendTextMessage(
                    phoneNumber,
                    null,
                    "Request to receive SMS from app",
                    null,
                    null
                )
                Toast.makeText(
                    this,
                    "Request sent to $phoneNumber to send SMS back",
                    Toast.LENGTH_SHORT
                ).show()
            } catch (e: Exception) {
                Toast.makeText(
                    this,
                    "Failed to send SMS request: ${e.message}",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
    }

    private fun openWhatsApp() {
        try {
            val uri = Uri.parse("https://api.whatsapp.com/send?phone=+91$phoneNumber")
            val whatsappIntent = Intent(Intent.ACTION_VIEW, uri)
            startActivity(whatsappIntent)
            Toast.makeText(this, "Opening WhatsApp for $phoneNumber", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "WhatsApp not installed or unable to open", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onCreateContextMenu(
        menu: ContextMenu?,
        v: View?,
        menuInfo: ContextMenu.ContextMenuInfo?
    ) {
        super.onCreateContextMenu(menu, v, menuInfo)
        menuInflater.inflate(R.menu.context_menu, menu)
    }

    override fun onContextItemSelected(item: MenuItem): Boolean {
        return when(item.itemId) {
            R.id.r4 -> {
                Toast.makeText(this, "Thanks for giving 4 stars", Toast.LENGTH_SHORT).show()
                true
            }
            R.id.r5 -> {
                Toast.makeText(this, "Thanks for giving 5 stars", Toast.LENGTH_SHORT).show()
                true
            }
            else -> super.onContextItemSelected(item)
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)

        if (requestCode == SMS_PERMISSION_REQUEST_CODE) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                receiveSMS()
            } else {
                Toast.makeText(
                    this,
                    "SMS permission denied. Cannot request SMS.",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
    }
}