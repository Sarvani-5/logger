package com.example.lab_83
import android.Manifest
import android.annotation.SuppressLint
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.icu.util.Calendar
import android.location.Geocoder
import android.location.Location
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import org.w3c.dom.Text
import java.util.Locale

class SettingsActivity : AppCompatActivity() {
    // Add FusedLocationClient property
    private lateinit var fusedLocationClient: FusedLocationProviderClient
    private val LOCATION_PERMISSION_REQUEST_CODE = 1001

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

        // Initialize FusedLocationProvider
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)

        val dbtn = findViewById<Button>(R.id.datebutton)
        val tbtn = findViewById<Button>(R.id.timebutton)
        val dtxt = findViewById<TextView>(R.id.DateView)
        val ttxt = findViewById<TextView>(R.id.TimeView)
        val cal = Calendar.getInstance()

        dbtn.setOnClickListener {
            val year = cal.get(Calendar.YEAR)
            val month = cal.get(Calendar.MONTH)
            val day = cal.get(Calendar.DAY_OF_MONTH)
            DatePickerDialog(this, { _, y, m, d ->
                dtxt.text = "$d/${m+1}/$y"
            }, year, month, day).show()
        }

        tbtn.setOnClickListener {
            val hour = cal.get(Calendar.HOUR_OF_DAY)
            val min = cal.get(Calendar.MINUTE)
            TimePickerDialog(this, { _, h, m ->
                ttxt.text = "$h:$m"
            }, hour, min, true).show()
        }

        val lat = findViewById<EditText>(R.id.latText)
        val lon = findViewById<EditText>(R.id.lonText)
        val progress = findViewById<ProgressBar>(R.id.pbar)
        val locbtn = findViewById<Button>(R.id.locbutton)
        val result = findViewById<TextView>(R.id.address)

        // Add button for getting current location
        val getCurrentLocationBtn = findViewById<Button>(R.id.fusedbutton)
        getCurrentLocationBtn.setOnClickListener {
            getCurrentLocation()
        }

        locbtn.setOnClickListener {
            progress.progress = 0
            val la = lat.text.toString().toDoubleOrNull()
            val lo = lon.text.toString().toDoubleOrNull()

            if (la == null || lo == null) {
                Toast.makeText(this, "Please enter valid latitude and longitude", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            Thread {
                for (i in 1..100) {
                    Thread.sleep(30)
                    runOnUiThread {
                        progress.progress = i
                    }
                }

                val geocoder = Geocoder(this, Locale.getDefault())
                try {
                    val addresses = geocoder.getFromLocation(la, lo, 1)
                    runOnUiThread {
                        if (addresses != null && addresses.isNotEmpty()) {
                            val address = addresses[0].getAddressLine(0)
                            result.text = "Address : $address"
                        } else {
                            Toast.makeText(this, "No address found for this location", Toast.LENGTH_SHORT).show()
                        }
                    }
                } catch (e: Exception) {
                    runOnUiThread {
                        Toast.makeText(this, "Error occurred in fetching address: ${e.message}", Toast.LENGTH_SHORT).show()
                    }
                }
            }.start()
        }
    }

    private fun getCurrentLocation() {
        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_FINE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.ACCESS_FINE_LOCATION),
                LOCATION_PERMISSION_REQUEST_CODE
            )
            return
        }

        fusedLocationClient.lastLocation
            .addOnSuccessListener { location ->
                if (location != null) {
                    // Update UI with location data
                    val lat = findViewById<EditText>(R.id.latText)
                    val lon = findViewById<EditText>(R.id.lonText)
                    lat.setText(location.latitude.toString())
                    lon.setText(location.longitude.toString())

                    Toast.makeText(this, "Location retrieved successfully", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(this, "Unable to get current location", Toast.LENGTH_SHORT).show()
                }
            }
            .addOnFailureListener { e ->
                Toast.makeText(this, "Error getting location: ${e.message}", Toast.LENGTH_SHORT).show()
            }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == LOCATION_PERMISSION_REQUEST_CODE) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                getCurrentLocation()
            } else {
                Toast.makeText(this, "Permission denied. Cannot get location.", Toast.LENGTH_SHORT).show()
            }
        }
    }
}