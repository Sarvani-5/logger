package com.example.lab_83

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import androidx.activity.OnBackPressedCallback
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        val sharedPref = getSharedPreferences("userPrefs", Context.MODE_PRIVATE)
        val name = findViewById<EditText>(R.id.dname)
        val phn = findViewById<EditText>(R.id.dphn)
        val donate = findViewById<Button>(R.id.ddonate)
        donate.setOnClickListener({
            val editor = sharedPref.edit()
            val u = name.text.toString()
            val p = phn.text.toString()
            editor.putString("username",u)
            editor.putString("phn",p)
            editor.apply()
            val intent = Intent(this,HomeActivity::class.java)
            startActivity(intent)
        })
    }

    override fun onBackPressed() {
        super.onBackPressed()
        val builder = AlertDialog.Builder(this)
        with(builder){
            setTitle("Exit app")
            setMessage("Are you sure you want to exit?")
            setPositiveButton("Yes"){_,_ ->finishAffinity()}
            setNegativeButton("No",null)
            setCancelable(true)
            show()
        }
    }
}